external_klogripper
===================

A CLI tool that outputs streaming dmesg. Making "adb shell klogripper" the dmesg equivalent of "adb logcat".

Original (http://git.goodpoint.de/?p=klogripper.git;a=summary) by Sebastian Pipping
Ported to Android by Eric McCann (Nuclearmistake)
